to start running with server use the following commands in this "server" directory,

-> npm install
-> npm start