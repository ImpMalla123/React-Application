export interface IProducts{
    id?:string;
    name:string;
    price:string;
    info:string;
    imageUrl:string;
    qty:string;
}