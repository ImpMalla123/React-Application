import React, { useState } from "react";


interface IProps{}
interface IState{}

let DeleteProduct:React.FC<IProps> =() =>{
   
    return(
        <>
            
           
           
        </>
    );

}

export default DeleteProduct;